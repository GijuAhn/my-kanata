# kanata-parser

A parser for configuration language of [kanata](https://github.com/jtroo/kanata).

This crate does not follow semver. It tracks the version of kanata.
