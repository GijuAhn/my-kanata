# key-sort-add

A small program that was used to sort and fill in OsCode mappings.
