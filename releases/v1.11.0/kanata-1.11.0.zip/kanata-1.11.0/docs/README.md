
### Converting ".adoc" to html

To generate html from the these documentation files, use ["asciidoctor"](https://asciidoctor.org)
(they are not fully compatible with the separate "asciidoc" project)

