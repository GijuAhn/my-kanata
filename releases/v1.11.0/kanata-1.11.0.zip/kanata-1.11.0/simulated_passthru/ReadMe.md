# Kanata passthru (simulated input and output)

A Windows dynamic library (DLL) that lets you run simulated kanata input and get simulated kanata output.

See a simplified [example](./../docs/simulated_passthru_ahk/) of using AutoHotkey to redirect custom inputhook's key events to kanata and get them remapped using kanata config, e.g., to get better modtap functionality
