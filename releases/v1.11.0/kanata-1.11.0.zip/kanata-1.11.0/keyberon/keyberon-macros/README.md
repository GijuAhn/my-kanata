# kanata keyberon macros

## Note

This is a fork intended for use by the [kanata keyboard remapper software](https://github.com/jtroo/keyberon).
Please make contributions to the [original project](https://github.com/TeXitoi/keyberon) where applicable.
