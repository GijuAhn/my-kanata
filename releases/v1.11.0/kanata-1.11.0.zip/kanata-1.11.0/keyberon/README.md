# kanata-keyberon

## Note

This is a fork intended for use by the [kanata keyboard remapper software](https://github.com/jtroo/kanata).
Please make contributions to the [original project](https://github.com/TeXitoi/keyberon) where applicable.

This crate does not follow semver. It tracks the version of kanata.
