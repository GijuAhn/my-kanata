# Kanata simulated input

A CLI tool that lets you run simulated kanata input.

Use the `-c` flag to specify a kanata configuration file
and the `-s` flag to specify an input simulation file.
You can pass the `--help` flag for more details.

The input file format is described in the
[guide](https://github.com/jtroo/kanata/blob/main/docs/config.adoc#test-your-config).

