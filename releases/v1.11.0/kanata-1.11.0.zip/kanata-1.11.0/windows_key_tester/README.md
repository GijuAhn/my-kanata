# Windows key tester

This directory contains the code for a Windows key tester. This can be used to
help test keyboard->keycode mappings in Windows that may not yet be listed in
kanata. For Linux, use the existing [evtest](https://www.systutorials.com/docs/linux/man/1-evtest/).
